# Blender Addon: blender-vertex-tools

Install by zipping this folder (or directly placing it) into Blender's addons directory, then enable it in Preferences > Add-ons.

Panel: View3D > UI > Mesh
Operator: mesh.example
